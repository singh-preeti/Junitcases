package com.testcase;

@FunctionalInterface
interface DoubleMath {
	
	double operation(double firstNumber, double secondNumber);

}